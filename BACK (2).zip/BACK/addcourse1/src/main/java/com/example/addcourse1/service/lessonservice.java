package com.example.addcourse1.service;

import com.example.addcourse1.entity.lesson;
import com.example.addcourse1.repository.lessonrepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class lessonservice {
    @Autowired
    private final lessonrepository lessonrepository; // Updated

    public List<lesson> getLessons() {
        return lessonrepository.findAll();
    }

    public Optional<lesson> getLessonById(Long lessonId) {
        return lessonrepository.findById(lessonId);
    }

    public lesson save(lesson lesson) {
        return lessonrepository.save(lesson); // Updated
    }

    public boolean existsById(Long lessonId) {
        return lessonrepository.existsById(lessonId);
    }

    public void deleteLesson(Long lessonId) {
        lessonrepository.deleteById(lessonId);
    }
}
