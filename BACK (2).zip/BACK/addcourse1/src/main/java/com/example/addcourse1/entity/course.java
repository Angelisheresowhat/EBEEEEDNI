package com.example.addcourse1.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Getter
@Setter
public class course {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name= "courseId")
    private long courseId;
    private String courseTitle;
    private String courseCategory;
    private String courseDescription;
    private String courseDuration;
    private int courseLevel;
    private boolean courseIsPremium;

    //@Lob
    private byte[] coursePhotoFile; // Add this line

    public boolean getCourseIsPremium() {
        return this.courseIsPremium;
    }

    @OneToMany(mappedBy = "course", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<lesson> courseLessons;
}


    // Uncomment the following if you have a recommendedCourses attribute
    /*
    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "recommended_courses",
            joinColumns = @JoinColumn(name = "course_id"),
            inverseJoinColumns = @JoinColumn(name = "recommended_course_id")
    )
    @JsonIgnoreProperties("recommendedCourses")
    private List<Course> recommendedCourses;
    */

