//package com.example.addcourse1.controller;
//
//import java.util.HashMap;
//import java.util.List;
//import com.example.addcourse1.entity.chapter;
//import com.example.addcourse1.service.chapterservice;
//import jakarta.persistence.EntityNotFoundException;
//import lombok.AllArgsConstructor;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@AllArgsConstructor
//@CrossOrigin("*")
//@RequestMapping("/api/v1")
//public class chaptercontroller {
//    private chapterservice chapterservice;
//
//    @GetMapping("/chapters")
//    public List<chapter> getChapters() {
//        return chapterservice.getChapters();
//    }
//
//    @GetMapping("/chapters/{chapterId}") // Updated
//    public ResponseEntity<?> getChapterById(@PathVariable Long chapterId) {
//        try {
//            chapter foundChapter = chapterservice.getChapterById(chapterId)
//                    .orElseThrow(() -> new EntityNotFoundException("Requested chapter not found"));
//            return ResponseEntity.ok().body(foundChapter);
//        } catch (EntityNotFoundException ex) {
//            HashMap<String, String> message = new HashMap<>();
//            message.put("message", "Chapter not found for id: " + chapterId);
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
//        }
//    }
//
//    @PostMapping("/chapters")
//    public chapter addChapter(@RequestBody chapter chapter) {
//        return chapterservice.save(chapter);
//    }
//
//    @PutMapping("/chapters/{chapterId}") // Updated
//    public ResponseEntity<?> addChapter(@RequestBody chapter chapter, @PathVariable Long chapterId) {
//        if (chapterservice.existsById(chapterId)) {
//            chapter chapter1 = chapterservice.getChapterById(chapterId)
//                    .orElseThrow(() -> new EntityNotFoundException("Requested chapter not found"));
//            chapter1.setChapterTitle(chapter.getChapterTitle());
//            chapter1.setChapterDescription(chapter.getChapterDescription());
//            chapter1.setChapterVideo(chapter.getChapterVideo());
//            chapter1.setLesson(chapter.getLesson());
//            chapterservice.save(chapter);
//            return ResponseEntity.ok().body(chapter1);
//        } else {
//            HashMap<String, String> message = new HashMap<>();
//            message.put("message", chapterId + " chapter not found or matched");
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
//        }
//    }
//
//    @DeleteMapping("/chapters/{chapterId}") // Updated
//    public ResponseEntity<?> deleteChapter(@PathVariable Long chapterId) {
//        if (chapterservice.existsById(chapterId)) {
//            chapterservice.deleteChapter(chapterId);
//            HashMap<String, String> message = new HashMap<>();
//            message.put("message", "Chapter with id " + chapterId + " was deleted successfully.");
//            return ResponseEntity.status(HttpStatus.OK).body(message); // Updated
//        } else {
//            HashMap<String, String> message = new HashMap<>();
//            message.put("message", chapterId + " chapter not found or matched");
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
//        }
//    }
//}
package com.example.addcourse1.controller;

import java.util.HashMap;
import java.util.List;
import com.example.addcourse1.entity.chapter;
import com.example.addcourse1.service.chapterservice;
import jakarta.persistence.EntityNotFoundException;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@CrossOrigin("*")
@RequestMapping("/api/v1")
public class chaptercontroller {
    @Autowired
    private chapterservice chapterService;

    @GetMapping("/chapters")
    public List<chapter> getChapters() {
        return chapterService.getChapters();
    }

    @GetMapping("/chapters/{chapterId}") // Updated
    public ResponseEntity<?> getChapterById(@PathVariable Long chapterId) {
        try {
            chapter foundChapter = chapterService.getChapterById(chapterId)
                    .orElseThrow(() -> new EntityNotFoundException("Requested chapter not found"));
            return ResponseEntity.ok().body(foundChapter);
        } catch (EntityNotFoundException ex) {
            HashMap<String, String> message = new HashMap<>();
            message.put("message", "Chapter not found for id: " + chapterId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
        }
    }

    @PostMapping("/chapters")
    public ResponseEntity<?> addChapter(@RequestBody chapter chapter) {
        try {
            chapter savedChapter = chapterService.save(chapter);
            return ResponseEntity.ok(savedChapter);
        } catch (Exception e) {
            HashMap<String, String> message = new HashMap<>();
            message.put("message", "Failed to add chapter");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(message);
        }
    }

    @PutMapping("/chapters/{chapterId}") // Updated
    public ResponseEntity<?> updateChapter(@RequestBody chapter chapter, @PathVariable Long chapterId) {
        if (chapterService.existsById(chapterId)) {
            chapter existingChapter = chapterService.getChapterById(chapterId)
                    .orElseThrow(() -> new EntityNotFoundException("Requested chapter not found"));
            existingChapter.setChapterTitle(chapter.getChapterTitle());
            existingChapter.setChapterDescription(chapter.getChapterDescription());
            existingChapter.setChapterVideo(chapter.getChapterVideo());
            existingChapter.setLesson(chapter.getLesson());
            chapterService.save(existingChapter);
            return ResponseEntity.ok().body(existingChapter);
        } else {
            HashMap<String, String> message = new HashMap<>();
            message.put("message", chapterId + " chapter not found or matched");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
        }
    }

    @DeleteMapping("/chapters/{chapterId}") // Updated
    public ResponseEntity<?> deleteChapter(@PathVariable Long chapterId) {
        if (chapterService.existsById(chapterId)) {
            chapterService.deleteChapter(chapterId);
            HashMap<String, String> message = new HashMap<>();
            message.put("message", "Chapter with id " + chapterId + " was deleted successfully.");
            return ResponseEntity.status(HttpStatus.OK).body(message); // Updated
        } else {
            HashMap<String, String> message = new HashMap<>();
            message.put("message", chapterId + " chapter not found or matched");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
        }
    }
}
