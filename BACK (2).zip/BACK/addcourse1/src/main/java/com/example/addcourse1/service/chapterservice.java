package com.example.addcourse1.service;

import com.example.addcourse1.entity.chapter;
import com.example.addcourse1.repository.chapterrepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class chapterservice {
    @Autowired
    private final chapterrepository chapterrepository; // Updated

    public List<chapter> getChapters() {
        return chapterrepository.findAll();
    }

    public Optional<chapter> getChapterById(Long chapterId) {
        return chapterrepository.findById(chapterId);
    }

    public chapter save(chapter chapter) {
        return chapterrepository.save(chapter); // Updated
    }

    public boolean existsById(Long chapterId) {
        return chapterrepository.existsById(chapterId);
    }

    public void deleteChapter(Long chapterId) {
        chapterrepository.deleteById(chapterId);
    }
}
