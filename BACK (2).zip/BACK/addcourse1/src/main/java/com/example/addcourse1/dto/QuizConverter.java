package com.example.addcourse1.dto;

import com.example.addcourse1.entity.quiz;

public class QuizConverter {

    public static QuizDTO toDTO(quiz entity) {
        QuizDTO dto = new QuizDTO();
        dto.setQuizId(entity.getQuizId());
        dto.setQuizQuestion(entity.getQuizQuestion());
        dto.setQuizCorrectAnswer(entity.getQuizCorrectAnswer());
        dto.setQuizScore(entity.getQuizScore());
        return dto;
    }

    public static quiz toEntity(QuizDTO dto) {
        quiz entity = new quiz();
        entity.setQuizId(dto.getQuizId());
        entity.setQuizQuestion(dto.getQuizQuestion());
        entity.setQuizCorrectAnswer(dto.getQuizCorrectAnswer());
        entity.setQuizScore(dto.getQuizScore());
        return entity;
    }
}
