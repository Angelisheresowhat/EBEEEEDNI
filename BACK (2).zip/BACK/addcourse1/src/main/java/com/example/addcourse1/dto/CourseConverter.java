package com.example.addcourse1.dto;

import com.example.addcourse1.entity.course;

public class CourseConverter {

    public static CourseDTO toDTO(course entity) {
        CourseDTO dto = new CourseDTO();
        dto.setCourseId(entity.getCourseId());
        dto.setCourseTitle(entity.getCourseTitle());
        dto.setCourseCategory(entity.getCourseCategory());
        dto.setCourseDescription(entity.getCourseDescription());
        dto.setCourseDuration(entity.getCourseDuration());
        dto.setcourseLevel(entity.getCourseLevel());
        dto.setcourseIsPremium(entity.getCourseIsPremium());
        // You can handle the coursePhotoFile conversion here if needed
        return dto;
    }

    public static course toEntity(CourseDTO dto) {
        course entity = new course();
        if (dto.getCourseId() != null && !dto.getCourseId().isEmpty()) {
            entity.setCourseId(Long.parseLong(dto.getCourseId()));
        }
        entity.setCourseTitle(dto.getCourseTitle());
        entity.setCourseCategory(dto.getCourseCategory());
        entity.setCourseDescription(dto.getCourseDescription());
        entity.setCourseDuration(dto.getCourseDuration());
        if (dto.getCourseLevel() != null && !dto.getCourseLevel().isEmpty()) {
            entity.setCourseLevel(Integer.parseInt(dto.getCourseLevel()));
        }
        if (dto.getCourseIsPremium() != null && !dto.getCourseIsPremium().isEmpty()) {
            entity.setCourseIsPremium(Boolean.parseBoolean(dto.getCourseIsPremium()));
        }
        // You can handle the coursePhotoFile conversion here if needed
        return entity;
    }
}
