package com.example.addcourse1.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.*;
import lombok.Getter;
import lombok.Setter;
import java.util.List;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Data
public class lesson {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name= "lessonId")
    private long lessonId;
    private String lessonTitle;
    private String lessonDescription;
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "courseId")
    private course course;
    @OneToMany(mappedBy = "lesson",cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<chapter> chapters;
    @OneToMany(mappedBy = "lesson", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    private List<quiz> quizzes;
}
