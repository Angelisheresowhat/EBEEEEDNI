package com.example.addcourse1.dto;

public class ChapterDTO {
    private long chapterId;
    private String chapterTitle;
    private String chapterDescription;
    private String chapterVideo;

    public long getChapterId() {
        return chapterId;
    }

    public void setChapterId(long chapterId) {
        this.chapterId = chapterId;
    }

    public String getChapterTitle() {
        return chapterTitle;
    }

    public void setChapterTitle(String chapterTitle) {
        this.chapterTitle = chapterTitle;
    }

    public String getChapterDescription() {
        return chapterDescription;
    }

    public void setChapterDescription(String chapterDescription) {
        this.chapterDescription = chapterDescription;
    }

    public String getChapterVideo() {
        return chapterVideo;
    }

    public void setChapterVideo(String chapterVideo) {
        this.chapterVideo = chapterVideo;
    }
}
