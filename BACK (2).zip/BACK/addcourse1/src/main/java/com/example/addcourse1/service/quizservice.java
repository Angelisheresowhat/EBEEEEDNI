package com.example.addcourse1.service;

import com.example.addcourse1.entity.quiz;
import com.example.addcourse1.repository.quizrepository;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@AllArgsConstructor
public class quizservice {
    @Autowired
    private final quizrepository quizrepository; // Updated

    public List<quiz> getQuizzes() {
        return quizrepository.findAll();
    }

    public Optional<quiz> getQuizById(Long quizId) {
        return quizrepository.findById(quizId);
    }

    public quiz save(quiz quiz) {
        return quizrepository.save(quiz); // Updated
    }

    public boolean existsById(Long quizId) {
        return quizrepository.existsById(quizId);
    }

    public void deleteQuiz(Long quizId) {
        quizrepository.deleteById(quizId);
    }
}
