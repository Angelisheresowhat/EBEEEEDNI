package com.example.addcourse1.controller;

import java.util.HashMap;
import java.util.List;

import com.example.addcourse1.dto.CourseConverter;
import com.example.addcourse1.dto.CourseDTO;
import com.example.addcourse1.entity.course;
import com.example.addcourse1.service.courseservice;
import jakarta.persistence.EntityNotFoundException;
import lombok.AllArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import javax.validation.Valid;
import org.springframework.http.MediaType;
import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;


@RestController

@CrossOrigin("*")
@RequestMapping("/api/v1")
public class coursecontroller {
	
	@Autowired
    private courseservice courseservice;

    @GetMapping("/courses")
    public List<course> getCourses() {
        return courseservice.getCourses();
    }

    @GetMapping("/courses/{courseId}")
    public ResponseEntity<?> getCourseById(@PathVariable Long courseId) {
        try {
            course foundCourse = courseservice.getCourseById(courseId)
                    .orElseThrow(() -> new EntityNotFoundException("Requested course not found"));
            return ResponseEntity.ok().body(foundCourse);
        } catch (EntityNotFoundException ex) {
            HashMap<String, String> message = new HashMap<>();
            message.put("message", "Course not found for id: " + courseId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
        }
    }
   // , consumes ={"application/octet-stream","multipart/form-data"}

   @PostMapping(path = "/courses")
   public ResponseEntity<?> addCourse(@RequestParam("course") String course, @RequestParam("file") MultipartFile file) {
	   try {
	  
	   ObjectMapper objectMapper = new ObjectMapper();

       CourseDTO courseDTO = objectMapper.readValue(course, CourseDTO.class);
	   course c=CourseConverter.toEntity(courseDTO);
	   c.setCoursePhotoFile(file.getBytes());
    	return ResponseEntity.ok(courseservice.save(c));
       
    } catch (Exception e) {
    	 e.printStackTrace();
    	return null;
       
    }
    
  }

@PutMapping("/courses/{courseId}")
public ResponseEntity<?> updateCourse(@RequestBody course course, @PathVariable Long courseId) {
    if (courseservice.existsById(courseId)) {
        course existingCourse = courseservice.getCourseById(courseId)
                .orElseThrow(() -> new EntityNotFoundException("Requested course not found"));
        // Update the existing course fields
        existingCourse.setCourseTitle(course.getCourseTitle());
        existingCourse.setCourseCategory(course.getCourseCategory());
        existingCourse.setCourseDescription(course.getCourseDescription());
        existingCourse.setCourseDuration(course.getCourseDuration());
        existingCourse.setCourseLevel(course.getCourseLevel());
        existingCourse.setCourseIsPremium(course.getCourseIsPremium());
        existingCourse.setCoursePhotoFile(course.getCoursePhotoFile());
        existingCourse.setCourseLessons(course.getCourseLessons());
        courseservice.save(existingCourse);
        return ResponseEntity.ok().body(existingCourse);
    } else {
        HashMap<String, String> message = new HashMap<>();
        message.put("message", courseId + " course not found or matched");
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
    }
}


    @DeleteMapping("/courses/{courseId}")
    public ResponseEntity<?> deleteCourse(@PathVariable Long courseId) {
        if (courseservice.existsById(courseId)) {
            courseservice.deleteCourse(courseId);
            HashMap<String, String> message = new HashMap<>();
            message.put("message", "Course with id " + courseId + " was deleted successfully.");
            return ResponseEntity.status(HttpStatus.OK).body(message);
        } else {
            HashMap<String, String> message = new HashMap<>();
            message.put("message", courseId + " course not found or matched");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
        }
    }
}