package com.example.addcourse1.controller;

public @interface Valid {

}
