package com.example.addcourse1.dto;

import com.example.addcourse1.entity.lesson;

public class LessonConverter {

    public static LessonDTO toDTO(lesson entity) {
        LessonDTO dto = new LessonDTO();
        dto.setLessonId(entity.getLessonId());
        dto.setLessonTitle(entity.getLessonTitle());
        dto.setLessonDescription(entity.getLessonDescription());
//        dto.setCourseId(entity.getCourse().getCourseId()); // Assuming courseId is a String in CourseDTO
        // You can add conversion for chapters and quizzes here if needed
        return dto;
    }

    public static lesson toEntity(LessonDTO dto) {
        lesson entity = new lesson();
        entity.setLessonId(dto.getLessonId());
        entity.setLessonTitle(dto.getLessonTitle());
        entity.setLessonDescription(dto.getLessonDescription());
        // You can set chapters and quizzes from dto here if needed
        return entity;
    }
}
//package com.example.addcourse1.dto;
//
//import com.example.addcourse1.entity.lesson;
//
//public class LessonConverter {
//
//    public static LessonDTO toDTO(lesson entity) {
//        LessonDTO dto = new LessonDTO();
//        dto.setLessonId(entity.getLessonId());
//        dto.setLessonTitle(entity.getLessonTitle());
//        dto.setLessonDescription(entity.getLessonDescription());
//        // You can handle the course conversion here if needed
//        // dto.setCourse(CourseConverter.toDTO(entity.getCourse()));
//        // You can handle the chapters conversion here if needed
//        // dto.setChapters(entity.getChapters());
//        // You can handle the quizzes conversion here if needed
//        // dto.setQuizzes(entity.getQuizzes());
//        return dto;
//    }
//
//    public static lesson toEntity(LessonDTO dto) {
//        lesson entity = new lesson();
//        if (dto.getLessonId() != null && !dto.getLessonId().isEmpty()) {
//            entity.setLessonId(Long.parseLong(dto.getLessonId()));
//        }
//        entity.setLessonTitle(dto.getLessonTitle());
//        entity.setLessonDescription(dto.getLessonDescription());
//        // You can handle the course conversion here if needed
//        // entity.setCourse(CourseConverter.toEntity(dto.getCourse()));
//        // You can handle the chapters conversion here if needed
//        // entity.setChapters(dto.getChapters());
//        // You can handle the quizzes conversion here if needed
//        // entity.setQuizzes(dto.getQuizzes());
//        return entity;
//    }
//}
