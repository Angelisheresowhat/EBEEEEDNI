//package com.example.addcourse1.controller;
//
//import java.util.HashMap;
//import java.util.List;
//import com.example.addcourse1.entity.lesson;
//import com.example.addcourse1.service.lessonservice;
//import jakarta.persistence.EntityNotFoundException;
//import lombok.AllArgsConstructor;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@AllArgsConstructor
//@CrossOrigin("*")
//@RequestMapping("/api/v1")
//public class lessoncontroller {
//    private lessonservice lessonservice;
//
//    @GetMapping("/lessons")
//    public List<lesson> getLessons() {
//        return lessonservice.getLessons();
//    }
//
//    @GetMapping("/lessons/{lessonId}") // Updated
//    public ResponseEntity<?> getLessonById(@PathVariable Long lessonId) {
//        try {
//            lesson foundLesson = lessonservice.getLessonById(lessonId)
//                    .orElseThrow(() -> new EntityNotFoundException("Requested lesson not found"));
//            return ResponseEntity.ok().body(foundLesson);
//        } catch (EntityNotFoundException ex) {
//            HashMap<String, String> message = new HashMap<>();
//            message.put("message", "Lesson not found for id: " + lessonId);
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
//        }
//    }
//
//    @PostMapping("/lessons")
//    public lesson addLesson(@RequestBody lesson lesson) {
//        return lessonservice.save(lesson);
//    }
//
//    @PutMapping("/lessons/{lessonId}") // Updated
//    public ResponseEntity<?> addLesson(@RequestBody lesson lesson, @PathVariable Long lessonId) {
//        if (lessonservice.existsById(lessonId)) {
//            lesson lesson1 = lessonservice.getLessonById(lessonId)
//                    .orElseThrow(() -> new EntityNotFoundException("Requested lesson not found"));
//            lesson1.setChapters(lesson.getChapters());
//            lesson1.setQuizzes(lesson.getQuizzes());
//            lesson1.setLessonTitle(lesson.getLessonTitle());
//            lesson1.setLessonDescription(lesson.getLessonDescription());
//            lessonservice.save(lesson);
//            return ResponseEntity.ok().body(lesson1);
//        } else {
//            HashMap<String, String> message = new HashMap<>();
//            message.put("message", lessonId + " lesson not found or matched");
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
//        }
//    }
//
//    @DeleteMapping("/lessons/{lessonId}") // Updated
//    public ResponseEntity<?> deleteLesson(@PathVariable Long lessonId) {
//        if (lessonservice.existsById(lessonId)) {
//            lessonservice.deleteLesson(lessonId);
//            HashMap<String, String> message = new HashMap<>();
//            message.put("message", "Lesson with id " + lessonId + " was deleted successfully.");
//            return ResponseEntity.status(HttpStatus.OK).body(message); // Updated
//        } else {
//            HashMap<String, String> message = new HashMap<>();
//            message.put("message", lessonId + " lesson not found or matched");
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
//        }
//    }
//}
package com.example.addcourse1.controller;

import java.util.HashMap;
import java.util.List;
import com.example.addcourse1.entity.lesson;
import com.example.addcourse1.service.lessonservice;
import jakarta.persistence.EntityNotFoundException;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@CrossOrigin("*")
@RequestMapping("/api/v1")
public class lessoncontroller {
    @Autowired
    private lessonservice lessonservice;

    @GetMapping("/lessons")
    public List<lesson> getLessons() {
        return lessonservice.getLessons();
    }

    @GetMapping("/lessons/{lessonId}")
    public ResponseEntity<?> getLessonById(@PathVariable Long lessonId) {
        try {
            lesson foundLesson = lessonservice.getLessonById(lessonId)
                    .orElseThrow(() -> new EntityNotFoundException("Requested lesson not found"));
            return ResponseEntity.ok().body(foundLesson);
        } catch (EntityNotFoundException ex) {
            HashMap<String, String> message = new HashMap<>();
            message.put("message", "Lesson not found for id: " + lessonId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
        }
    }

    @PostMapping("/lessons")
    public lesson addLesson(@RequestBody lesson lesson) {
        return lessonservice.save(lesson);
    }

    @PutMapping("/lessons/{lessonId}")
    public ResponseEntity<?> updateLesson(@RequestBody lesson lesson, @PathVariable Long lessonId) {
        if (lessonservice.existsById(lessonId)) {
            lesson existingLesson = lessonservice.getLessonById(lessonId)
                    .orElseThrow(() -> new EntityNotFoundException("Requested lesson not found"));
            existingLesson.setChapters(lesson.getChapters());
            existingLesson.setQuizzes(lesson.getQuizzes());
            existingLesson.setLessonTitle(lesson.getLessonTitle());
            existingLesson.setLessonDescription(lesson.getLessonDescription());
            lessonservice.save(existingLesson);
            return ResponseEntity.ok().body(existingLesson);
        } else {
            HashMap<String, String> message = new HashMap<>();
            message.put("message", lessonId + " lesson not found or matched");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
        }
    }

    @DeleteMapping("/lessons/{lessonId}")
    public ResponseEntity<?> deleteLesson(@PathVariable Long lessonId) {
        if (lessonservice.existsById(lessonId)) {
            lessonservice.deleteLesson(lessonId);
            HashMap<String, String> message = new HashMap<>();
            message.put("message", "Lesson with id " + lessonId + " was deleted successfully.");
            return ResponseEntity.status(HttpStatus.OK).body(message);
        } else {
            HashMap<String, String> message = new HashMap<>();
            message.put("message", lessonId + " lesson not found or matched");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
        }
    }
}
