//package com.example.addcourse1.controller;
//
//import java.util.HashMap;
//import java.util.List;
//import com.example.addcourse1.entity.quiz;
//import com.example.addcourse1.service.quizservice;
//import jakarta.persistence.EntityNotFoundException;
//import lombok.AllArgsConstructor;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.*;
//
//@RestController
//@AllArgsConstructor
//@CrossOrigin("*")
//@RequestMapping("/api/v1")
//public class quizcontroller {
//    private quizservice quizservice;
//
//    @GetMapping("/quizzes")
//    public List<quiz> getQuizzes() {
//        return quizservice.getQuizzes();
//    }
//
//    @GetMapping("/quizzes/{quizId}") // Updated
//    public ResponseEntity<?> getQuizById(@PathVariable Long quizId) {
//        try {
//            quiz foundQuiz = quizservice.getQuizById(quizId)
//                    .orElseThrow(() -> new EntityNotFoundException("Requested quiz not found"));
//            return ResponseEntity.ok().body(foundQuiz);
//        } catch (EntityNotFoundException ex) {
//            HashMap<String, String> message = new HashMap<>();
//            message.put("message", "Quiz not found for id: " + quizId);
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
//        }
//    }
//
//    @PostMapping("/quizzes")
//    public quiz addQuiz(@RequestBody quiz quiz) {
//        return quizservice.save(quiz);
//    }
//
//    @PutMapping("/quizzes/{quizId}") // Updated
//    public ResponseEntity<?> addQuiz(@RequestBody quiz quiz, @PathVariable Long quizId) {
//        if (quizservice.existsById(quizId)) {
//            quiz quiz1 = quizservice.getQuizById(quizId)
//                    .orElseThrow(() -> new EntityNotFoundException("Requested quiz not found"));
//            quiz1.setQuizQuestion(quiz.getQuizQuestion());
//            quiz1.setQuizCorrectAnswer(quiz.getQuizCorrectAnswer());
//            quiz1.setQuizScore(quiz.getQuizScore());
//            quiz1.setLesson(quiz.getLesson());
//            quizservice.save(quiz);
//            return ResponseEntity.ok().body(quiz1);
//        } else {
//            HashMap<String, String> message = new HashMap<>();
//            message.put("message", quizId + " quiz not found or matched");
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
//        }
//    }
//
//    @DeleteMapping("/quizzes/{quizId}") // Updated
//    public ResponseEntity<?> deleteQuiz(@PathVariable Long quizId) {
//        if (quizservice.existsById(quizId)) {
//            quizservice.deleteQuiz(quizId);
//            HashMap<String, String> message = new HashMap<>();
//            message.put("message", "Quiz with id " + quizId + " was deleted successfully.");
//            return ResponseEntity.status(HttpStatus.OK).body(message); // Updated
//        } else {
//            HashMap<String, String> message = new HashMap<>();
//            message.put("message", quizId + " quiz not found or matched");
//            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
//        }
//    }
//}
package com.example.addcourse1.controller;

import java.util.HashMap;
import java.util.List;

import com.example.addcourse1.entity.quiz;
import com.example.addcourse1.service.quizservice;
import jakarta.persistence.EntityNotFoundException;
import lombok.AllArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import javax.validation.Valid;
import org.springframework.http.MediaType;
import java.io.IOException;
import com.fasterxml.jackson.databind.ObjectMapper;


@RestController

@CrossOrigin("*")
@RequestMapping("/api/v1")
public class quizcontroller {

    @Autowired
    private quizservice quizservice;

    @GetMapping("/quizzes")
    public List<quiz> getQuizzes() {
        return quizservice.getQuizzes();
    }

    @GetMapping("/quizzes/{quizId}")
    public ResponseEntity<?> getQuizById(@PathVariable Long quizId) {
        try {
            quiz foundQuiz = quizservice.getQuizById(quizId)
                    .orElseThrow(() -> new EntityNotFoundException("Requested quiz not found"));
            return ResponseEntity.ok().body(foundQuiz);
        } catch (EntityNotFoundException ex) {
            HashMap<String, String> message = new HashMap<>();
            message.put("message", "Quiz not found for id: " + quizId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
        }
    }

    @PostMapping(path = "/quizzes")
    public ResponseEntity<?> addQuiz(@RequestParam("quiz") String quizData) {
        try {

            ObjectMapper objectMapper = new ObjectMapper();

            quiz quiz = objectMapper.readValue(quizData, quiz.class);
            return ResponseEntity.ok(quizservice.save(quiz));

        } catch (Exception e) {
            e.printStackTrace();
            return null;

        }

    }

    @PutMapping("/quizzes/{quizId}")
    public ResponseEntity<?> updateQuiz(@RequestBody quiz quiz, @PathVariable Long quizId) {
        if (quizservice.existsById(quizId)) {
            quiz existingQuiz = quizservice.getQuizById(quizId)
                    .orElseThrow(() -> new EntityNotFoundException("Requested quiz not found"));
            // Update the existing quiz fields
            existingQuiz.setQuizQuestion(quiz.getQuizQuestion());
            existingQuiz.setQuizCorrectAnswer(quiz.getQuizCorrectAnswer());
            existingQuiz.setQuizScore(quiz.getQuizScore());
            existingQuiz.setLesson(quiz.getLesson());
            quizservice.save(existingQuiz);
            return ResponseEntity.ok().body(existingQuiz);
        } else {
            HashMap<String, String> message = new HashMap<>();
            message.put("message", quizId + " quiz not found or matched");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
        }
    }


    @DeleteMapping("/quizzes/{quizId}")
    public ResponseEntity<?> deleteQuiz(@PathVariable Long quizId) {
        if (quizservice.existsById(quizId)) {
            quizservice.deleteQuiz(quizId);
            HashMap<String, String> message = new HashMap<>();
            message.put("message", "Quiz with id " + quizId + " was deleted successfully.");
            return ResponseEntity.status(HttpStatus.OK).body(message);
        } else {
            HashMap<String, String> message = new HashMap<>();
            message.put("message", quizId + " quiz not found or matched");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(message);
        }
    }
}
