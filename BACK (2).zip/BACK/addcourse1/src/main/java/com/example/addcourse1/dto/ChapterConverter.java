package com.example.addcourse1.dto;

import com.example.addcourse1.entity.chapter;

public class ChapterConverter {

    public static ChapterDTO toDTO(chapter entity) {
        ChapterDTO dto = new ChapterDTO();
        dto.setChapterId(entity.getChapterId());
        dto.setChapterTitle(entity.getChapterTitle());
        dto.setChapterDescription(entity.getChapterDescription());
        dto.setChapterVideo(entity.getChapterVideo());
        return dto;
    }

    public static chapter toEntity(ChapterDTO dto) {
        chapter entity = new chapter();
        entity.setChapterId(dto.getChapterId());
        entity.setChapterTitle(dto.getChapterTitle());
        entity.setChapterDescription(dto.getChapterDescription());
        entity.setChapterVideo(dto.getChapterVideo());
        return entity;
    }
}
