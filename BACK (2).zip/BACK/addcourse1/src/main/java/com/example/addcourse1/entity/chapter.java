package com.example.addcourse1.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Getter
@Setter
public class chapter {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name= "chapterId")
    private long chapterId;
    private String chapterTitle;
    private String chapterDescription;
    private String chapterVideo;
    @ManyToOne
    @JoinColumn(name = "lessonId")
    @JsonIgnore
    private lesson lesson;
}
