package com.example.addcourse1.service;

import com.example.addcourse1.entity.course;
import com.example.addcourse1.repository.courserepository;
import lombok.AllArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class courseservice {
	@Autowired
    private courserepository courserepository;

    public List<course> getCourses() {
        return courserepository.findAll();
    }

    public Optional<course> getCourseById(Long courseId) {
        return courserepository.findById(courseId);
    }

    public course save(course course) {
    	
        return courserepository.saveAndFlush(course);
    }

    public boolean existsById(Long courseId) {
        return courserepository.existsById(courseId);
    }

    public void deleteCourse(Long courseId) {
        courserepository.deleteById(courseId);
    }
}
