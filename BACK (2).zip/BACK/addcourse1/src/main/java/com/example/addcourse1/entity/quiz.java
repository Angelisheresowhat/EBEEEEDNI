package com.example.addcourse1.entity;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Getter
@Setter
public class quiz {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name= "quizId")
    private long quizId;
    private String quizQuestion;
    private String quizCorrectAnswer;
    private int quizScore;
    @ManyToOne
    @JoinColumn(name = "lessonId")
    @JsonIgnore
    private lesson lesson;
}


