package com.example.addcourse1.dto;
import org.springframework.web.multipart.MultipartFile;

public class CourseDTO {
    private String courseId;
    private String courseTitle;
    private String courseCategory;
    private String courseDescription;
    private String courseDuration;
    private String courseLevel;
    private String courseIsPremium;
   

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public String getCourseTitle() {
        return courseTitle;
    }

    public void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }

    public String getCourseCategory() {
        return courseCategory;
    }

    public void setCourseCategory(String courseCategory) {
        this.courseCategory = courseCategory;
    }

    public String getCourseDescription() {
        return courseDescription;
    }

    public void setCourseDescription(String courseDescription) {
        this.courseDescription = courseDescription;
    }

    public String getCourseDuration() {
        return courseDuration;
    }

    public void setCourseDuration(String courseDuration) {
        this.courseDuration = courseDuration;
    }

    public String getCourseLevel() {
        return courseLevel;
    }

    public void setCourseLevel(String courseLevel) {
        this.courseLevel = courseLevel;
    }

    public String getCourseIsPremium() {
        return courseIsPremium;
    }

    public void setCourseIsPremium(String courseIsPremium) {
        this.courseIsPremium = courseIsPremium;
    }

    public void setcourseLevel(int courseLevel) {
    }

    public void setcourseIsPremium(boolean courseIsPremium) {
    }

    public void setCourseId(long courseId) {

    }
}
